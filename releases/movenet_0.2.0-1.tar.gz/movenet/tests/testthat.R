library(testthat)
library(movenet)

test_check("movenet")
