## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(movenet)

# Load example movenet-format movement and holding tibbles into the global environment:
movement_data <- head(fake_Scottish_movement_data, 100)
holding_data <- fake_Scottish_holding_data

## ----warning = FALSE----------------------------------------------------------
# Create a networkDynamic from our data
network <- movedata2networkDynamic(movement_data, holding_data,
                                   incl_nonactive_holdings = FALSE)
network

## -----------------------------------------------------------------------------
# Find the maximum reachability in the network, and which nodes have this property.
parallel_summarise_temporal_node_properties(list(network), n_threads = 1,
                                            node_property = "forward reachability",
                                            statistics = list(max = max),
                                            identify_nodes = TRUE)

## ---- eval = FALSE------------------------------------------------------------
#  # Create a network analysis report, with analyses of monthly network snapshots
#  create_temporal_network_analysis_report(
#    network,
#    output_file = paste0(tempdir(),"\\network_report.yml"),
#    incl_reachability_analysis = FALSE,
#    n_threads = 1,
#    whole_months = TRUE,
#    time_unit = "month")
#  

