## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(movenet)

## -----------------------------------------------------------------------------
xfun::file_string(system.file("configurations", "ScotEID.yml", package="movenet"))

## -----------------------------------------------------------------------------
# Load a pre-installed config file by using just its name:
load_config("ScotEID")
# Alternatively, provide the path to any configurations file:
load_config(system.file("configurations", "fakeScotEID_holding.yml", package="movenet"))

## -----------------------------------------------------------------------------
# Query the values of specific configurations: 
get_config("movedata_fileopts.separator", "holdingdata_cols.id")

## -----------------------------------------------------------------------------
# Query the values of all configurations: 
get_config()

## ----eval = FALSE-------------------------------------------------------------
#  # Save the currently loaded movement configurations to a new config file:
#  save_config("saved_movement_config.yml", config_type = "movement")

## ----eval = FALSE-------------------------------------------------------------
#  # Copy the movement config file template to your working directory:
#  new_config(config_type = "movement")

## -----------------------------------------------------------------------------
# Change the values of specific configurations: 
change_config("movedata_fileopts.separator" = ";", "holdingdata_cols.id" = "foo")
# Inspect the changed values in the movenet environment:
get_config("movedata_fileopts.separator", "holdingdata_cols.id")

## ----eval=FALSE---------------------------------------------------------------
#  .onLoad <- function(libname, pkgname){
#    load_config("ScotEID")
#  }

