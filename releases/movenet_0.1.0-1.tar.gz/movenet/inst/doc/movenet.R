## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(movenet)

## -----------------------------------------------------------------------------
xfun::file_string(system.file("configurations", "ScotEID.yml", package="movenet"))

## -----------------------------------------------------------------------------
load_config(system.file("configurations", "ScotEID.yml", package="movenet")) # Load ScotEID.yml

get_config() # Inspect the configurations in the movenet environment

## -----------------------------------------------------------------------------
head(read.csv(system.file("extdata", "fake_Scottish_movement_data.csv", package="movenet"), 
              encoding = "UTF-8"))

## -----------------------------------------------------------------------------
movement_data <- 
  reformat_data(system.file("extdata", "fake_Scottish_movement_data.csv", package="movenet"),
                type = "movement")

head(movement_data) # Inspect the resulting movement_data tibble

## -----------------------------------------------------------------------------
# Load a holding config file:
load_config(system.file("configurations", "fakeScotEID_holding.yml", package="movenet")) 
# Read in and reformat a holding data file:
holding_data <- 
  reformat_data(system.file("extdata", "fake_Scottish_holding_data.csv", package="movenet"),
                type = "holding")

