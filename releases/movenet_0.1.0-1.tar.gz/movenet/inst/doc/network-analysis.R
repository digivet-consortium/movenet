## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(movenet)

# Load example movenet-format movement and holding tibbles into the global environment:
movement_data <- head(fake_Scottish_movement_data, 100)
holding_data <- fake_Scottish_holding_data

## ----warning = FALSE----------------------------------------------------------
# Create a networkDynamic from our data
network <- movedata2networkDynamic(movement_data, holding_data,
                                   incl_nonactive_holdings = FALSE)
network

## -----------------------------------------------------------------------------
# Perform some analysis - find the maximum reachability
parallel_max_reachabilities(list(network), n_threads = 4)

